package Stack;

public class Node {
	
		private int data ;
		private Node pre ;
		
		public Node(int data) {
		
			this.data =data;
			this.pre =null;
		}
		
		public int getData() {
			return data;
		}

		public void setData(int data) {
			this.data = data;
		}
		
		
		public Node getPrev() {
			return pre;
		}

		public void setPrev(Node pre) {
			this.pre = pre;
		}

	

	}

