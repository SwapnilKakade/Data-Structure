package Stack;

public class DynamicStackMain {

	public static void main(String[] args) {
		DynamicStack ds = new DynamicStack();
		ds.push(10);
		ds.push(20);
		ds.push(30);
		ds.push(40);
		ds.display();
		
		ds.pop();
		ds.peek();
	}

}
