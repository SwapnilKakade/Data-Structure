package Stack;

public class Stackmain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stackmethod s = new Stackmethod(5);
		s.push(10);
		s.push(20);
		s.push(30);
		s.display();
		System.out.println();
		s.pop();
		s.pop();
		s.display();
		System.out.println();
		s.peek();

	}

}
