package Stack;

public class DynamicStack{

	Node top;

	public DynamicStack() {
	
		this.top = null ;
	}

	public void push(int val) {
		Node new_node = new Node(val);
		
		if(isEmpty()) {
			top = new_node;
			return ;
		}
		
		new_node.setPrev(top);
		top = new_node;
	
		
	}
	

	public void pop() {
		if(isEmpty()) {
			System.out.println("Stack is empty ");
			return ;
		}
		
		Node i = top;
		System.out.println("Pop element is \n" + top.getData());
		top = top.getPrev();
		i.setPrev(null);
	}
	

	public void peek() {
		if(isEmpty()) {
			System.out.println("Stack is empty");
			return ;
		}
		System.out.println("Top Most element is \n " + top.getData());
	}
	
	
	public void display() {
		System.out.println("Stack Elements");
		if(isEmpty()) {
			System.out.println("Stack is empty");
			return ;
		}
		for(Node i = top ; i != null ; i = i.getPrev()) {
			
			System.out.println(i.getData());
		}
	}
	
	public boolean isEmpty() {
		if(top == null) {
			return true;
		}
			return false;
	}

	
}
