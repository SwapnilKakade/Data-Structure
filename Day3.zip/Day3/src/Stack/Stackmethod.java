package Stack;

public class Stackmethod {
	 int data [];
	 int top ;
	 
	 public Stackmethod(int size) {
			super();
			data = new int[size];
			top = -1;
		}
	 
	public int getTop() {
		return top;
	}

	public void setTop(int top) {
		this.top = top;
	}

	public void push( int val) {
		if(isFull()) {
			System.out.println("Stack is full");
			return ;
		}
		
		data[++top] = val;
	}
	 
	public int pop() {
		if(isEmpty()) {
			System.out.println("Stack is empty");
			return -1 ;
		}
		
		return data[top--];
	}
	
	public int peek() {
		if(isEmpty()) {
			System.out.println("Stack is empty");
			return -1 ;
		}
		
		return data[top];
	}
	
	public void display() {
		if(isEmpty()) {
			System.out.println("Stack is empty");
			return ;
		}
		
		for(int i = top ; i>=0 ;i--) {
			System.out.println(data[i]);
		}
	}
	public boolean isFull() {
		if(top == data.length - 1) {
			return  true;
		}
		return false;
	}
	public boolean isEmpty() {
		if(top == -1) {
			return true;
		}
		return false;
	}
}