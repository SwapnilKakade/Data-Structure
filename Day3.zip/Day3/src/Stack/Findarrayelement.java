package Stack;

import java.util.Scanner;

public class Findarrayelement {

//	Write a Java program to find the index of an array element.
	
	
	public static void main(String[] args) {
		Scanner sn =new Scanner(System.in);
		int arr[] = {1,5,3,4,9,99,45};
		System.out.println("Enter the element");
		int n = sn.nextInt();
		boolean flag = true;
		for(int i = 0 ; i <= arr.length-1 ; i++) {
			if(arr[i]==n) {
				System.out.println("Index number is " + i);	
				flag = false;
				break;
			}
		}
		if(flag)System.out.println("Not found");
		
	}

}
