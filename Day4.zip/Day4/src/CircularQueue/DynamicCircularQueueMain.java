package CircularQueue;

public class DynamicCircularQueueMain {

	public static void main(String[] args) {
		
		 DynamicCircularQueue dc = new  DynamicCircularQueue();
		 
		 dc.enqueue();

	}

}
