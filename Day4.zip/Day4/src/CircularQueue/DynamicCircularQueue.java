package CircularQueue;

public class DynamicCircularQueue {
	
	private DCQNode front ,rear;

	public DynamicCircularQueue() {
		super();
		this.front = null;
		this.rear = null;
	}

	public DCQNode getFront() {
		return front;
	}

	public void setFront(DCQNode front) {
		this.front = front;
	}

	public DCQNode getRear() {
		return rear;
	}

	public void setRear(DCQNode rear) {
		this.rear = rear;
	}

	public void enqueue() {
		// TODO Auto-generated method stub
		
	}
	
	

}
