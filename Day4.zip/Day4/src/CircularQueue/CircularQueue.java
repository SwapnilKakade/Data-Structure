package CircularQueue;

public class CircularQueue {
	
	private int data[];
	private int  r,f;
	
	public CircularQueue(int size) {
		data = new int [size];
		r =  f = -1;
	}

	public int getR() {
		return r;
	}

	public void setR(int r) {
		this.r = r;
	}

	public int getF() {
		return f;
	}

	public void setF(int f) {
		this.f = f;
	}

	public void equeue(int val) {
		if(isFull()){
			System.out.println("Circular Queue is full");
			return ;
		}
		if(r == -1)
			f = 0 ;
		data[++r%data.length] = val ;
		
	}

	public int dqueue() {
		if(isEmpty()) {
			System.out.println("Circular Queue is empty");
			return 1 ;
		}
		int val = data[f++%data.length];
		if(f == r + 1)
			r = f = -1 ;
		return val;
		
		
	}
	
	

	public void display() {
		if(isEmpty()) {
			System.out.println("Circular Queue is empty");
			return ;
		}
		
		for(int i = f ; i <= r;i++) {
			System.out.println(data[i%data.length]);
		}
		
	}
	
	public boolean isFull() {
		if((r == data.length -1 && f == 0)|| f == r + 1) {
			return true;
		}
		return false;
	}
	
	public boolean isEmpty(){
		if( r== -1) {
		return true ;
		}
	return false ;
	
	}
}

