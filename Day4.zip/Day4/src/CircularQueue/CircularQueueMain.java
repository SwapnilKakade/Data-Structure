package CircularQueue;

public class CircularQueueMain {

	public static void main(String[] args) {
		CircularQueue cq = new CircularQueue(5);
		cq.equeue(10);
		cq.equeue(50);
		cq.equeue(90);
		System.out.println("The Dequeue element in circular Queue is "+cq.dqueue());
		cq.display();
	
	}

}
