package CircularQueue;

public class DCQNode {

	private int data ;
	private DCQNode next ;
	
	public DCQNode(int data) {
		super();
		this.data = data;
		this.next = null;
	}
	public int getData() {
		return data;
	}
	public void setData(int data) {
		this.data = data;
	}
	public DCQNode getNext() {
		return next;
	}
	public void setNext(DCQNode next) {
		this.next = next;
	}
	
	
}
