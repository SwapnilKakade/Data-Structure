package Queue;

public class DynQueue {
	
	private QNode front,rear;

	public DynQueue() {
		setFront(null);
		setRear(null);
	}

	public QNode getFront() {
		return front;
	}

	public void setFront(QNode front) {
		this.front = front;
	}

	public QNode getRear() {
		return rear;
	}

	public QNode setRear(QNode rear) {
		this.rear = rear;
		return rear ;
	}
	
	public void enque(int val) {
		QNode new_node = new QNode(val);
		if(new_node == null)
			return ;
		if(rear == null)
			rear =  front = new_node;
		else
		{
			rear.setNext(new_node);
			rear = new_node;
		}
		
	}
	
	public QNode dequeue() {
		if(isEmpty()) {
			System.out.println("Stack is empty");
			return null;
		}
		QNode t =front ;
		front = front.getNext();
		t.setNext(null);
		return t;
	}
	
	public void display() {
		if(isEmpty()) {
			System.out.println("Queue is empty");
			return ;
		}
		
		for(QNode t = front ; t != null ; t = t.getNext()) {
			System.out.println(t.getData());
		}
	}
	
	public QNode peak() {
		if(isEmpty()) {
			System.out.println("Stack is empty");
			return null ;
		}
		return front;
	}
	
	public boolean isEmpty() {
		
		return rear==null;
		
			
	}

}
