package Queue;

public class ArrayQueue {
	
	private int data[];
	private int r ,f;
	
	public ArrayQueue(int size) {
		data = new int[size];
		r = f = -1 ;
	}

	public int getR() {
		return r;
	}

	public void setR(int r) {
		this.r = r;
	}

	public int getF() {
		return f;
	}

	public void setF(int f) {
		this.f = f;
	}

	public void equeue(int val) {

		if(isFull()) {
			System.out.println("Queue is full");
			return ;
		}
		
		if(r == -1)
			f=0;
		data[++r] = val;
		
	}

	public int dqueue() {
		if(isEmpty()) {
			System.out.println("Queue is Empty");
			return 1;
		}
		int val = data[f++];
		if(f == r+1)
			r = f = -1;
		return val ;
	}

	public int peak() {
		if(isEmpty()) {
			System.out.println("Stack is empty");
			return 1;
		}
		
		return data[f];
		
	}
	 

	public void display() {

		if(isEmpty()) {
			System.out.println("Queue is Empty");
			return ;
		}
		
		for(int i = f ; i <= r ; i++) {
			System.out.println(data[i]);
		}
		
	}

	public boolean isFull() {
		if(r == data.length -1) {
			return true ;
		}
		return false;
	}
	
	public boolean isEmpty() {
		if(r == -1) {
			return true;
		}
		return false;
	}
	
}
