package Queue;

public class DynQueueMain {

	public static void main(String[] args) {
		DynQueue dq = new DynQueue();
		dq.enque(10);
		dq.enque(20);
		dq.enque(90);
		dq.enque(50);
		dq.display();
		System.out.println("The dequeue element is "+dq.dequeue().getData());
		dq.display();
		System.out.println(("The most peak element is " +dq.peak().getData()));
	}

}
