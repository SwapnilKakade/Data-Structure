                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              package Queue;

public class ArrayQueueMain {

	public static void main(String[] args) {
		
		ArrayQueue q = new ArrayQueue(5);
		
		System.out.println("Insert Elements in Queue");
		q.equeue(50);
		q.equeue(20);
		q.equeue(30);
		q.equeue(50);
		System.out.println("First  element of Queue " +q.peak());
		int val = q.dqueue();
		if(val != 1)
			System.out.println("Deleted element form Queue "+val);
		q.display();
	}

}
