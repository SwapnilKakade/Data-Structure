package Sorting;

public class MergeSort {

	int [] array;
	int [] tempMergeArr;
	int length ;
	public static void main(String[] args) {
		int [] arr = {1,5,6,44,2,443,8,99};
		MergeSort ms = new MergeSort();
		ms.sort(arr);
		ms.display(arr);
	}

	private void display(int arr[]) {
		for(int i : arr) {
			System.out.print(" "+i);
		}
	}

	public void sort( int arr []) {
		this.array = arr ;
		this.length = arr.length;
		this.tempMergeArr = new int[length];
		divideArray(0,length -1);
	}

	public void divideArray(int low, int high) {
	
		if(low < high) {
			int mid = low + (high - low)/2;
			//left sort 
			divideArray(low ,mid);
			//Right sort
			divideArray(mid + 1 ,high);
			mergeArray(low,mid,high);
		}
	}

	private void mergeArray(int low, int mid, int high) {
		for(int  i = low ; i <= high ; i++) {
			tempMergeArr[i] = array[i];
		}
		int  i= low ;
		int  j = mid + 1 ;
		int k = low ;
		
		while ( i <= mid && j <= high ) {
			if(tempMergeArr[i] <= tempMergeArr[j]) {
				array[k] = tempMergeArr[i];
				i++;
			}
			else {
				array[k] = tempMergeArr[j];
				j++;
			}
			k++;
		}
		while(i<=mid) {
			array[k]= tempMergeArr[i];
			k++;
			i++;
		}
	}
}
