package Sorting;
 
import java.util.Scanner;
public class LinearSearch {

	public static void main(String[] args) {
	
		Scanner sn = new Scanner(System.in);
		System.out.println("Enter no of elements");
		int n = sn.nextInt();
		
		int arr[] =new int [n];
		
		System.out.println("Enter the elements");
		for(int i = 0 ; i < arr.length ; i++) {
			arr [i] = sn.nextInt(); 
		}
		
		System.out.println("Enter search element");
		int item = sn.nextInt();
		
		boolean flag = false ;
		for(int i = 0 ; i < arr.length ; i++) {
	
			if(arr[i] == item  ) {
				System.out.println("Item is present at  " + i +" index position");
				
				flag = true ;
			}
		}
		if(flag == false) {
			System.out.println("Element is not found ");
		}
	}
}
