package Sorting;

public class BubbleSort {

	public static void main(String[] args) {
	
		int arr[] = {10,6,9,5,7,63};
		int temp ;	
		for(int i = 0 ; i < arr.length ; i++) {
			boolean flag = false ;
			for(int j = 0 ; j< arr.length -1 - i ; j ++ ) {
				 
				if(arr[j] > arr[j+1]) {		
					temp = arr[j];
					arr[j] = arr[j+1];
					arr[j+1] = temp ;
					flag = true ;
				}
			}
			if(flag == false) {
				break ;
			}
		}
		
		System.out.println("  Sorting elements ");
		for(int i = 0 ; i < arr.length ; i++) {
			System.out.print(" "+arr[i]);
		}
	}

}
/*
For string sorting 
 String arr[] = {"swapnil","ganesh","sumedh"};
string temp ;

if(a[j].compareTo(arr.[min]))>0)
*/
