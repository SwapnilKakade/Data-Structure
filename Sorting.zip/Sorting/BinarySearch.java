package Sorting;

public class BinarySearch 
{

	public static void main(String[] args)
	{

		int arr[] = {2,6,7,8,9,44,55,66,323,555};  
		int  low = 0,high = arr.length -1 ;
		int search = 9 ;
		int mid = (low + high )/2 ;
		
		while (low <= high) 
		{
			if(arr[mid] == search) {
				System.out.println("Element index position is " + mid );
				break ;
			}
			else if (arr[mid]< search)
			{
				low = mid + 1 ;
			}
			else 
			{
				high = mid - 1 ;
			}
			mid = (low + high )/2;
		}
		if(low >high)
		{
			System.out.println("Element not found");
		}
	}
}
