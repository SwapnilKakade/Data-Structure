package Day1;

public class SinglyCiculatListM {

	public static void main(String[] args) {
		SinglyCicularListNode sc = new SinglyCicularListNode();
		
		sc.addFirst(10);
		sc.addLast(50); 
		sc.addFirst(120);
		sc.addPos(12,2);
		sc.display();
	}

}
