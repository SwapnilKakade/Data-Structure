package LinkedList;

public class RevStackMain {

	public static void main(String[] args) {
	
		reverseString();
	}

	private static void reverseString() {
		String str = "Hello";
		System.out.println("String str : "+ str);
		
		RevStack rs = new RevStack(str.length());
		
		for(int i = 0; i<str.length();i++) {
			rs.push(str.charAt(i));
		}
		
		String s1 ="";
		for(int i = 0; i<str.length();i++) {
			s1+=rs.pop();
		}
		
		System.out.println("String after Reverse str : " +s1);
	}

}
