package Day1;

public class SinglyCicularListNode {
	
	static class Node {
		private int data ;
		private Node next ;
	
		public Node() {
			data = 0 ;
			next = null;
		}
		public Node(int val) {
			data = val ;
			next = null ;
		}
	}
	
	private Node head ;

	public SinglyCicularListNode() {
		head = null;
	}
// To check list is empty
	public boolean isEmpty() {
		return head == null;
	}
	
// To display list
	public void display() {
		System.out.println("List of elements");
		 if(isEmpty()) {
			 return ;
		 }
		 Node trav = head ;
		 do {
			 System.out.println(trav.data);
			 trav = trav.next;
		 }while(trav != head); 
	}
	
// To insert element in last
	public void addLast(int val) {
		Node new_node = new Node(val);
	//	System.out.println(val);
		if(isEmpty()) {
			head = new_node     ;
			new_node.next = head ;
		}
		else {
			Node trav = head ;
			while(trav != head) {
				trav = trav.next;
			}
			new_node.next =head;	
			trav.next =new_node;
		}		
	}
	
// insert at first
	public void addFirst(int val) {
		Node new_node = new Node(val);
		if(isEmpty()) {
			head = new_node;
			new_node.next = head;
		}
		else {
			Node trav = head ;
			while(trav.next != head) 
				trav =trav.next;
				new_node.next = head;
				trav.next = new_node;
			head = new_node ;
		}
	}
	
	
// insert at position
public void addPos(int val, int pos) {
		
		if(head == null || pos<= 1)
			addFirst(val);
		
		else {
			Node new_node = new Node(val);
			Node trav = head ;
			for(int i =1 ;i <= pos - 1 ; i++) {
				if(trav.next == head)
					break ;
				trav =  trav.next ;
			}
			new_node.next = trav.next;
			trav.next = new_node ;
		}
		
	}
}
