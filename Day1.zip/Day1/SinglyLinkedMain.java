package Day1;

public class SinglyLinkedMain {

	public static void main(String[] args) {
		
				SinglyLinkedList  sl = new SinglyLinkedList ();	
				sl.addFirst(10);
				sl.addFirst(60);
				sl.addFirst(20);
				sl.addLast(50);
				sl.addLast(80);
				sl.addPos(16,2);
				sl.delFirst();
				sl.display();
				sl.delLast();
				sl.delPos(3);
//			sl.delAll();
//			sl.display();
				
	}
}
