package LinkedList;

public class RevStack {
	
		char data[] ;
		int top ;
		public RevStack(int size) {
			data = new char[size];
			top = -1;
		}
		public void push(char val) {
			data [++top] = val;
		}
		public char pop() {
			return data [top --];
		}
		
		
}
