package LinkedList;
import java.util.Scanner;

class SinglylinearList{
		static class Node{
			private int data;
			private Node next;
		
		public Node() {
			data = 0;
			next =null;
		}
		 
		public Node(int val) {
			data = val;
			next = null;
		}

	}
	
	private Node head ;

	public SinglylinearList() {
		head = null;
	}
	
	void display() {
		System.out.println("list");
		Node trav = head;
		while(trav!=null) {
						System.out.println(trav.data);
						trav = trav.next;
		}
		System.out.println("");
	}
	
	void addFirst(int val) {
		Node new_node =new Node(val);
		new_node.next=head;
		head=new_node;	
	}
	
	void addLast(int val) {
		Node new_node =new Node(val);
		if(head==null) {
			head = new_node;
		}
		else {
			Node trav = head;
			while(trav.next != null) 
				trav=trav.next;	
			trav.next=new_node;
		}
	}
	
	void addPos(int val,int pos) {
		//special conditon
		if(head == null  || pos <= 1) {
			addFirst(val);
		}
		else {
			Node new_node =new Node(val);
			Node trav = head;
			
			for(int i = 1 ;i<pos-1;i++) { 
				if(trav.next==null)   
					break;
				trav=trav.next;
			}
				new_node.next = trav.next;
				trav.next=new_node;
		}
	}
	
	void delFirst() {
		if(head ==  null) 
			throw new RuntimeException("List is empty");
		head = head.next;
	}
	
	void delAll() {
		head = null;
	}

	public void delPos(int pos) {
		if(pos==1)
			delFirst();
		
		if(head == null || pos < 1)
			throw new RuntimeException("List is empty");
		 Node temp =null, trav =head;
		 
		 for(int i =1;i<pos;i++) {
			 if(trav == null)
				 throw new RuntimeException("List is empty");
				 temp=trav;
				 trav=trav.next;
		 }
		temp.next=trav.next;
	}

	public void delLast() {
	if(head ==  null)
		throw new RuntimeException("List is empty");
		
	if(head.next == null) {
		head =null;
	}
	else {
		Node temp=null,trav=head;
		while(trav.next != null) {
			temp = trav;
			trav = trav.next;
		}
		temp.next  = null ;
	}
	} 
} 
 // Main class
public class SinglyList {

	public static void main(String[] args) {
		int choise,val,pos;
		
		SinglylinearList list =new SinglylinearList();
		Scanner sn = new Scanner(System.in);
	
		do {
			System.out.println("\n 0.Exit\n 1.display \n 2.AddFirst \n 3.Addlast \n 4.Addpos \n 5.DelFirst \n 6.DelAll \n7.DelPos \n8.DelLast");
			
			choise =sn.nextInt();
			switch(choise) {
			
			case 1:
				list.display();
				break;
				
			case 2:
				System.out.println("Enter the new element ");
				val = sn.nextInt();
				list.addFirst(val);
				break;
			case 3:
				System.out.println("Enter the new element ");
				val = sn.nextInt();
				list.addLast(val);
				break;
			case 4:
				System.out.println("Enter the new element ");
				val = sn.nextInt();
				System.out.println("Enter the postion ");
				pos = sn.nextInt();
				list.addPos(val,pos);
				break;	
			
			case 5:
				try {
					list.delFirst();
				}
				catch(Exception e) {
					System.out.println(e.getMessage());
				}
				break;
				
			case 6:
				list.delAll();
				break;
				
			case 7:
				System.out.println("Enter element position");
				pos=sn.nextInt();
				list.delPos(pos);
				break;
		
			case 8:
				try {
					list.delLast();
				}
				catch(Exception e) {
					System.out.println(e.getMessage());
				}
				break;
			}
		}while(choise!=0);	
	}
}
