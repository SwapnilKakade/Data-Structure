package LinkedList;
//How do you find the length of a singly linked list?

class SLLlength{
	
	class Node{
		int data ;
		Node next ;
		 public Node(int val) {
			 data = val;
			 next = null ;
		 }
	}
	Node head;
	
	public void push(int data) {
		
		Node new_node = new Node(data);
		new_node.next =head;
		head = new_node ;	
	}
	
	public int getCount() {
		
		Node temp = head;
		int count = 0;
		 while (temp != null) {
			 count ++;
			 temp = temp.next;
		 }	
		 return count;
	}
}


public class LengthSLL {
	public static void main(String[] args) {
		
		SLLlength sl = new SLLlength();
		sl.push(10);
		sl.push(20);
		sl.push(30);
		sl.push(40);
		System.out.println("Count of nodes is : " + sl.getCount());	
	}
}
