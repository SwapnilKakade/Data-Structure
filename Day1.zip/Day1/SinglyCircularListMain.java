package LinkedList;

class SinglyCircularList{
	
	static class Node {
			private int data ;
			private Node next;
	
			public Node() {
				data = 0;
				next = null;
			}

			public Node(int val) { 
				data = val;
				next = null;
			}	
		}
	
	private  Node head;
	
	public SinglyCircularList() {
		head = null;
	}
	
	public boolean isEmpty() {
		return head == null;
	}
	
	
	public void display() {
		System.out.println("List");
		if(isEmpty())
			return;
		 Node trav =head;
		 do {
			 System.out.println(trav.data);
			 trav = trav.next;
		 }while(trav != head);
	}

	public void addLast(int val) {
		Node new_node = new Node(val);     //create node	
		if(isEmpty()) {
			head = new_node;
			new_node.next =head;
		}
		else {
			Node trav =head;                                                         // intilize
					while(trav.next != head) {
							trav =trav.next;
					}
			new_node.next = head;                                                //new node next to head
			trav.next = new_node;                                         //last nodes trav next to newnode
		}
	}
	 
	public void addFirst (int val) {
		Node new_node = new Node(val);
		
		if(isEmpty()) {
			head = new_node;
			new_node.next = head;
		}
		else {
			Node trav =head;
			while(trav.next != head) {
				trav =  trav.next;
			}
			
			new_node.next = head;
			trav.next = new_node;
			head = new_node;
		}
	}

	public void addAtpos(int val, int pos) {
		 
		if(head == null || pos<=1)
			return ;
		Node new_node = new Node(val);
		
		Node trav = head ;
		for(int i = 1 ; i<pos-1 ;i++) {
			if(trav.next != head)
				break;
			trav = trav.next;
		}
		new_node.next  = trav.next;
		trav.next = new_node;
		
	}
}

// This is main method
public class SinglyCircularListMain {

	public static void main(String[] args) {
		SinglyCircularList list = new SinglyCircularList();
		
		list.addFirst(10);
		list.addFirst(20);
		list.addFirst(30);
		list.display();
		list.addLast(40);
		list.display();
		list.addAtpos(32,2);
		list.addAtpos(36,11);
		list.display();
	}
}
