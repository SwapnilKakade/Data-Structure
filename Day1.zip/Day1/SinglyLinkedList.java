package Day1;

public class SinglyLinkedList {
	
	//Static node class
	static class Node {
		private int data ;
		private Node next ;
		public Node() {
			data = 0;
			next = null ;
		}
		public Node (int val) {
			data = val ;
			next = null;
		}
	}
	private Node head ;
	
	public SinglyLinkedList() {
		head = null ;
	}
// Insert the element
	 void addFirst(int val) {
		Node new_node = new Node(val);
		new_node.next= head ;
		head = new_node;
	}
	
// Display Element
	 void display() {
		Node temp = head ;
		System.out.println("Element list");
		while (temp != null) {
			System.out.println(temp.data);
			temp = temp.next;
		}
		
	}
// Insert last index element
	
	 void addLast(int val) {
		Node new_node = new Node(val);
		if(head == null) {
			head = new_node ;
		}
		else {
			Node temp = head ;
			while(temp.next  != null) {
				temp = temp.next;
			}
			temp.next = new_node;
		}
	}
	// Insert at position 
	 public void addPos(int val, int pos) {
			
			if(head == null  || pos <=1) {
				addFirst(val);
			}
			else {
				Node new_node = new Node(val);
				Node temp = head ;
				for(int i = 1 ; i<pos-1 ;i++) {
					if(temp.next == null)
						break ;
					temp = temp.next;
				}
				new_node.next = temp.next;
				temp.next = new_node;
			}
		}
	 
	 // delete at first
	public void delFirst() {
		if(head == null)
			System.out.println("Empty");
		else {
		head = head.next;
		}
	}

	// delete all
	public void delAll() {
		head=null;
		System.out.println("List is empty");
	}
	
	// delete last element
	
	public void delLast() {
		if(head == null)
			System.out.println("Empty");
		
		if(head.next ==  null) {
			head = null;
		}
		else {
			Node temp =null ;
			while(head.next != null) {
				temp = head ;
				head = head.next;
			}
			temp.next = null;
		}		
	}
	
	//delete at position
	public void delPos(int pos) {
	
		if(pos == 1){
			delFirst();
		}
		if(head == null || pos <1 )
			System.out.println("Empty");
		
		Node temp = null  ,trav = head;
		for (int i = 1 ; i<pos ; i++) {
			if(trav == null)
				System.out.println("Empty");
			temp = trav ;
			trav = trav.next ;
		}
		
		temp.next = trav.next;
	}
}
